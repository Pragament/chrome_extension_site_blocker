// Simple DOM and common helpers shared across the extension

// DOM helpers
function $(id) { return document.getElementById(id); }
function setHidden(el, hidden) { if (el) el.classList[hidden ? 'add' : 'remove']('hidden'); }
function setText(el, text) { if (el) el.textContent = text; }

// Data helpers
function normalizeLines(text) {
  return text
    .split("\n")
    .map(l => l.trim())
    .filter(l => l.length > 0);
}

// Export to global scope
// eslint-disable-next-line no-undef
self.$ = $;
// eslint-disable-next-line no-undef
self.setHidden = setHidden;
// eslint-disable-next-line no-undef
self.setText = setText;
// eslint-disable-next-line no-undef
self.normalizeLines = normalizeLines;

function showNotificationPermissionModal() {
  // Check if modal already exists
  if (document.getElementById('notificationPermissionModal')) return;

  const overlay = document.createElement('div');
  overlay.id = 'notificationPermissionModal';
  overlay.className = 'notification-modal-overlay';
  overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.5); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 100000; font-family: sans-serif;';

  const card = document.createElement('div');
  card.className = 'notification-modal-card';
  card.style.cssText = 'background: white; padding: 24px; border-radius: 12px; max-width: 400px; width: 95%; box-shadow: 0 10px 25px rgba(0,0,0,0.15); text-align: center; display: flex; flex-direction: column; gap: 16px; border: 1px solid #e2e8f0;';

  card.innerHTML = `
    <h3 style="font-size: 20px; font-weight: bold; color: #1e293b; margin: 0; display: flex; align-items: center; justify-content: center; gap: 8px;">
      🔔 Enable Notifications
    </h3>
    <p style="font-size: 14px; color: #64748b; line-height: 1.5; margin: 0;">
      Notifications must be enabled to receive class questions and solver answers in real time. Please click below to grant permission.
    </p>
    <button id="grantNotificationPermissionBtn" style="background: #3b82f6; color: white; border: none; padding: 10px 20px; font-size: 14px; font-weight: bold; border-radius: 6px; cursor: pointer; transition: background 0.2s;">
      Enable Notifications
    </button>
    <div id="permissionBlockGuide" style="display: none; font-size: 12px; color: #ef4444; line-height: 1.4; margin-top: 8px;">
      <strong>Browser blocked permission prompt!</strong><br>
      Please open <strong>Chrome Settings -> Privacy and security -> Site settings -> Notifications</strong> and allow notifications for this extension origin.
    </div>
  `;

  overlay.appendChild(card);
  document.body.appendChild(overlay);

  const btn = card.querySelector('#grantNotificationPermissionBtn');
  const guide = card.querySelector('#permissionBlockGuide');

  btn.addEventListener('click', async () => {
    btn.disabled = true;
    btn.textContent = 'Requesting...';
    try {
      const permission = await Notification.requestPermission();
      console.log('[FCM Permission Dialog] Outcome:', permission);
      if (permission === 'granted') {
        const modal = document.getElementById('notificationPermissionModal');
        if (modal) modal.remove();
        setupFCM();
      } else {
        btn.textContent = 'Permission Denied';
        btn.style.backgroundColor = '#94a3b8';
        guide.style.display = 'block';
      }
    } catch (e) {
      console.error('[FCM Permission Dialog] Error:', e);
      guide.style.display = 'block';
      btn.textContent = 'Retry';
      btn.disabled = false;
    }
  });
}

async function getExtensionServiceWorkerRegistration() {
  try {
    const registrations = await navigator.serviceWorker.getRegistrations();
    console.log('[FCM Setup] Found active service worker registrations:', registrations.map(r => r.active?.scriptURL));
    
    let registration = registrations.find(r => r.active && r.active.scriptURL.includes('background.js'));
    if (registration) {
      console.log('[FCM Setup] Successfully resolved background.js registration from getRegistrations().');
      return registration;
    }
    
    console.log('[FCM Setup] background.js registration not found in getRegistrations(). Attempting to register background.js...');
    registration = await navigator.serviceWorker.register('background.js');
    console.log('[FCM Setup] Programmatically registered background.js. Scope:', registration.scope);
    return registration;
  } catch (err) {
    console.error('[FCM Setup] Failed to resolve service worker registration:', err);
    return null;
  }
}

async function setupFCM() {
  console.log('[FCM] setupFCM() called.');
  console.log('[FCM] Notification permission status:', Notification.permission);
  
  if (Notification.permission !== 'granted') {
    console.warn('[FCM] Notification permission is not granted. Current state:', Notification.permission);
    showNotificationPermissionModal();
    return;
  }
  
  try {
    const { studentInfo } = await chrome.storage.local.get('studentInfo');
    if (!studentInfo || !studentInfo.classCode || !studentInfo.rollNumber) {
      console.log('[FCM] No student credentials configured. Skipping FCM registration.');
      return;
    }
    
    // Initialize Firebase in option/dashboard window context
    if (typeof firebase !== 'undefined') {
      if (firebase.apps.length === 0) {
        firebase.initializeApp(self.CONFIG.FIREBASE);
      }
      console.log('[FCM] Firebase initialized.');
      const messaging = firebase.messaging();
      
      // Bind token refresh listener
      messaging.onTokenRefresh(async () => {
        console.log('[FCM] Firebase issued a new registration token.');
        console.log('[FCM] Token regenerated and why: Firebase onTokenRefresh fired.');
        await chrome.storage.local.remove('fcmToken');
        setupFCM();
      });
      
      // Retrieve the existing local token from storage
      const { fcmToken: existingToken } = await chrome.storage.local.get('fcmToken');
      console.log('[FCM] Local FCM token:', existingToken || 'None');
      
      // Get the active background service worker registration
      const registration = await getExtensionServiceWorkerRegistration();
      if (!registration) {
        console.error('[FCM] Extension service worker registration not found.');
        return;
      }
      
      let vapidKey = (self.CONFIG && self.CONFIG.FIREBASE && self.CONFIG.FIREBASE.vapidKey) || undefined;
      if (vapidKey && vapidKey.length !== 87) {
        console.warn(`[FCM] Configured VAPID key "${vapidKey}" is malformed (length ${vapidKey.length}, expected 87). Falling back to default FCM VAPID key.`);
        vapidKey = 'BDOU99-h67HcA6JeFXHbSNMu7e2yNNu3RzoMj8TM4W88jITfq7ZmPvIM1Iv-4_l2LxQcYwhqby2xGpWwzjfAnG4';
      }
      
      console.log('[FCM] Checking current token from Firebase...');
      let token = null;
      try {
        token = await messaging.getToken({
          serviceWorkerRegistration: registration,
          vapidKey: vapidKey
        });
      } catch (err) {
        console.warn('[FCM] Failed to get initial token:', err);
      }
      
      if (!token) {
        console.log('[FCM] Token regenerated and why: No existing cached token found.');
        token = await messaging.getToken({
          serviceWorkerRegistration: registration,
          vapidKey: vapidKey
        });
      }
      
      console.log('[FCM] Retrieved current cached token:', token || 'None');
      
      let registrationExists = false;
      let registrationMatches = false;
      let checkFailed = false;
      
      if (token) {
        // Verify with backend if the registration exists and matches
        console.log('[FCM] Verifying token registration on backend...');
        try {
          const checkRes = await chrome.runtime.sendMessage({
            type: 'checkFcmToken',
            classCode: studentInfo.classCode,
            rollNumber: studentInfo.rollNumber,
            fcmToken: token
          });
          
          if (checkRes && checkRes.success) {
            registrationExists = !!checkRes.exists;
            registrationMatches = !!checkRes.matches;
          } else {
            checkFailed = true;
          }
        } catch (err) {
          console.warn('[FCM] Backend check failed due to network error:', err);
          checkFailed = true;
        }
      } else {
        checkFailed = true;
      }
      
      if (checkFailed) {
        console.log('[FCM] Registration skipped and why: Express server check failed or network offline. Reusing existing token.');
        return;
      }
      
      console.log('[FCM] Backend registration exists or not:', registrationExists);
      console.log('[FCM] Token match or mismatch:', registrationMatches ? 'match' : 'mismatch');
      
      let registrationRequestSent = false;
      
      if (!registrationExists || !registrationMatches) {
        console.log('[FCM] Token regenerated and why: Backend registration is missing or mismatched.');
        
        // Deleting cached token to force Firebase to issue a brand new registration token
        try {
          if (token) {
            console.log('[FCM] Deleting old token...');
            await messaging.deleteToken();
            console.log('[FCM] Old token deleted.');
          }
        } catch (err) {
          console.warn('[FCM] Failed to delete token:', err.message || err);
        }
        
        console.log('[FCM] Generating fresh token...');
        token = await messaging.getToken({
          serviceWorkerRegistration: registration,
          vapidKey: vapidKey
        });
        
        console.log('[FCM] Newly generated token:', token || 'None');
        
        if (token) {
          registrationRequestSent = true;
          console.log('[FCM] Registration request sent.');
          await chrome.storage.local.set({ fcmToken: token });
          
          // Upload token to Firestore via Express backend
          const res = await chrome.runtime.sendMessage({
            type: 'registerFcmToken',
            classCode: studentInfo.classCode,
            rollNumber: studentInfo.rollNumber,
            studentName: studentInfo.studentName || '',
            fcmToken: token
          });
          
          if (res && res.success) {
            console.log('[FCM] Registration successful.');
          } else {
            console.error('[FCM] Token upload failed:', res?.message || 'Unknown error');
          }
        } else {
          console.error('[FCM] Failed to generate a new FCM token.');
        }
      } else {
        console.log('[FCM] Registration request sent:', registrationRequestSent);
        console.log('[FCM] Registration skipped and why: Backend registration document already exists and matches the current FCM token.');
      }
    } else {
      console.warn('[FCM] Firebase SDK is not loaded in this window context.');
    }
  } catch (error) {
    console.error('[FCM] Error during setupFCM execution:', error);
  }
}

// Listen for background worker events to re-run setupFCM (e.g. on service worker restarts)
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === 'trigger_fcm_setup') {
      console.log('[FCM Page Listener] Received trigger_fcm_setup from background script.');
      setupFCM();
    }
  });
}

self.setupFCM = setupFCM;


